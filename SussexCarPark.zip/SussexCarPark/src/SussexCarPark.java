
public class SussexCarPark implements CarPark {
    //!!!! There will be an error here until you implement the methods in the interface !!!
}
